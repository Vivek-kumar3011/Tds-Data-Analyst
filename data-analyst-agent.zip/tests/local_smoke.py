
import io, json, requests

def test_wiki_route():
    q = """Scrape the list of highest grossing films from Wikipedia. It is at the URL:
https://en.wikipedia.org/wiki/List_of_highest-grossing_films

Answer the following questions and respond with a JSON array of strings containing the answer.

1. How many $2 bn movies were released before 2000?
2. Which is the earliest film that grossed over $1.5 bn?
3. What's the correlation between the Rank and Peak?
4. Draw a scatterplot of Rank and Peak along with a dotted red regression line through it.
   Return as a base-64 encoded data URI, "data:image/png;base64,iVBORw0KG..." under 100,000 bytes.
"""
    files = {'questions': ('questions.txt', q)}
    r = requests.post("http://localhost:8000/api/", files=files, timeout=120)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list) and len(data) == 4
